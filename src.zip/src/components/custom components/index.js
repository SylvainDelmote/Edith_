export  {default as checkbox} from './CustomCheckbox.ce.vue'
export  {default as div} from './CustomDiv.ce.vue'
export  {default as span} from './CustomSpan.ce.vue'
export  {default as img} from './CustomImage.ce.vue'
