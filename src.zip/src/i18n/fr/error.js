export default {
  'NetworkError when attempting to fetch resource.': 'Erreur réseau lors de l\'accés à la ressource',
  'Not Found': 'Non trouvé',
  'Network Error' : 'Erreur réseau ou de CORS',
  'Request failed with status code 500' : '500 - Erreur API - merci de contacter un administrateur'
}
