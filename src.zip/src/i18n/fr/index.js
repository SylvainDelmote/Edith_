import global from './global'
import error from './error'
import appli from './appli'

export default {
  ...global,
  ...error,
  ...appli
}
