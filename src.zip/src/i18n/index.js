import fr from './fr'

export default {
  fr: fr
}
