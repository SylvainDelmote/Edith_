<template>
  <div class="fullscreen text-center q-pa-md flex flex-center">
    <div>
      <div class="text-h2 q-pb-xl">
        404
      </div>

      <div class="text-h2 q-pb-xl" style="opacity:.4">
        Désolé, rien ici...
      </div>

      <q-btn
        color="accent"
        icon="undo"
        label="Retour"
        no-caps
        style="width:200px;"
        to="/"
      />
    </div>
  </div>
</template>

