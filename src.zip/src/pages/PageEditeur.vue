<script setup>
import DocumentEditor from 'src/components/DocumentEditor.vue';
</script>

<template>
  <q-page class="flex flex-center">
    <DocumentEditor/>
  </q-page>


</template>

