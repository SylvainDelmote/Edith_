export default [
  {
    name: 'roles',
    path: '/roles',
    component: () => import('pages/RolesUser.vue')
  },
  // {
  //   name: 'profil',
  //   path: '/profil',
  //   component: () => import('pages/ProfilUser.vue')
  // }
]
